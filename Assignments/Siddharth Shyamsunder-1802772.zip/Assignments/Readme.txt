If in case the datasets are not accesible you will find them in my github repository

https://github.com/SIDDHARTHSS93/ce888labs/tree/master/Assignments/Datasets%20and%20code